#!/bin/sh
MODDIR=${0%/*}

$MODDIR/Memory.sh
$MODDIR/Piero.sh
$MODDIR/Atlantis
